package com.example.friendutil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * Void DLS click-GUI (Delta-style): one draggable dark panel per category with an animated accent line.
 * LMB on a module toggles it, RMB opens its settings, click a header to fold it, drag a header to move it.
 */
public class MenuScreen extends Screen {

    private static final String[][] CATEGORIES = {
            {"Combat", "killaura", "ka_crits", "triggerbot", "aimassist", "autototem", "autogapple"},
            {"Movement", "fly", "speed", "step", "spider", "jesus", "autosprint"},
            {"Render", "esp_players", "esp_mobs", "esp_items", "gearview", "ore_esp", "trajectory", "targethud", "dmgnum", "hitfx", "cooldowns", "fullbright"},
            {"PvE", "mobaura", "autoeat", "autotool", "autofish", "automine", "autowarden"},
            {"Misc", "autorespawn", "autowalk", "antiafk", "coords"},
            {"Effects", "targetesp", "trails", "jumpcircles", "blockoverlay", "worldpart", "fog"}
    };
    private static final String[][] ORES = {
            {"Coal", "coal_ore"}, {"Iron", "iron_ore"}, {"Copper", "copper_ore"}, {"Gold", "gold_ore"},
            {"Redstone", "redstone_ore"}, {"Lapis", "lapis_ore"}, {"Diamond", "diamond_ore"},
            {"Emerald", "emerald_ore"}, {"Quartz", "quartz_ore"}, {"Debris", "ancient_debris"}
    };

    private static final int PANELS = CATEGORIES.length + 2;      // Ores panel, then World
    private static final int ORES_PANEL = PANELS - 2;
    private static final int WORLD_PANEL = PANELS - 1;
    private static final int HH = 13, RH = 11, GAP = 2;

    private static final boolean[] OPEN = {true, true, true, true, true, true, false, true};
    private static final int[] PX = new int[PANELS];
    private static final int[] PY = new int[PANELS];
    private static boolean placed = false;
    private static final Set<String> EXPANDED = new HashSet<>();

    // swatch: small color square on the row (header of a color setting); pick: a palette grid row
    private record Row(String text, int color, boolean on, Runnable click, Runnable rclick,
                       IntSupplier swatch, IntConsumer pick) {
        Row(String text, int color, boolean on, Runnable click, Runnable rclick) {
            this(text, color, on, click, rclick, null, null);
        }
    }

    private static final int SW = 9;                              // palette cell size
    private static final Set<String> PAL_OPEN = new HashSet<>();

    private int palCols() {
        return Math.max(1, (w - 6) / SW);
    }

    private int rowH(Row r) {
        if (r.pick() == null) return RH;
        int n = FriendUtilClient.COLOR_NAMES.length;
        return ((n + palCols() - 1) / palCols()) * SW + 3;
    }

    // "Color: Name" header (click = open the palette, RMB = next color) + the palette grid under it
    private static List<Row> colorRows(String key, IntSupplier get, IntConsumer set) {
        List<Row> o = new ArrayList<>();
        int n = FriendUtilClient.COLOR_NAMES.length;
        o.add(new Row("  Color: " + FriendUtilClient.COLOR_NAMES[get.getAsInt()], 0xFFFFFF55, false,
                () -> { if (!PAL_OPEN.remove(key)) PAL_OPEN.add(key); },
                () -> set.accept((get.getAsInt() + 1) % n), get, null));
        if (PAL_OPEN.contains(key)) o.add(new Row("", 0, false, null, null, get, set));
        return o;
    }


    private int w = 80;
    private int dragPanel = -1, dragDX, dragDY;
    private boolean dragMoved = false;
    private EditBox box;

    public MenuScreen() {
        super(Component.literal("Void DLS"));
    }

    private static Module find(String id) {
        for (Module m : FriendUtilClient.modules()) {
            if (m.id.equals(id)) return m;
        }
        return null;
    }

    private static String title(int p) {
        return p == ORES_PANEL ? "Ores" : p == WORLD_PANEL ? "World" : CATEGORIES[p][0];
    }

    private static Row cycleRow(String label, String[] names, IntSupplier get, IntConsumer set) {
        int n = names.length;
        return new Row("  " + label + ": " + names[get.getAsInt()], 0xFFFFFF55, false,
                () -> set.accept((get.getAsInt() + 1) % n),
                () -> set.accept((get.getAsInt() + n - 1) % n));
    }

    private static boolean hasSettings(String id) {
        switch (id) {
            case "automine": case "autowarden": case "hitfx": case "ore_esp": case "targetesp": case "trails":
            case "jumpcircles": case "blockoverlay": case "worldpart": case "fog":
                return true;
            default:
                return false;
        }
    }

    private static List<Row> settingsRows(String id) {
        List<Row> o = new ArrayList<>();
        switch (id) {
            case "automine":
                o.add(new Row("  Pickup: " + (FriendUtilClient.mineAutoPickup ? "On" : "Off"), 0xFFFFFF55, false,
                        () -> FriendUtilClient.mineAutoPickup = !FriendUtilClient.mineAutoPickup, null));
                o.add(new Row("  Return: " + (FriendUtilClient.mineReturnHome ? "On" : "Off"), 0xFFFFFF55, false,
                        () -> FriendUtilClient.mineReturnHome = !FriendUtilClient.mineReturnHome, null));
                break;
            case "autowarden":
                o.add(new Row("  Open at " + FriendUtilClient.wardenOpenAt + "s", 0xFFFFFF55, false, () ->
                        FriendUtilClient.wardenOpenAt = FriendUtilClient.wardenOpenAt >= 5 ? 0 : FriendUtilClient.wardenOpenAt + 1,
                        null));
                o.add(new Row("  Route: " + FriendUtilClient.wardenQueueSize() + " an", 0xFF888888, false, null, null));
                break;
            case "hitfx":
                o.addAll(colorRows("hit", () -> FriendUtilClient.hitColor, v -> FriendUtilClient.hitColor = v));
                o.add(cycleRow("Count", FriendUtilClient.COUNT_NAMES, () -> FriendUtilClient.hitCount, v -> FriendUtilClient.hitCount = v));
                o.add(new Row("  World: " + (FriendUtilClient.hitWorldFx ? "On" : "Off"), 0xFFFFFF55, false,
                        () -> FriendUtilClient.hitWorldFx = !FriendUtilClient.hitWorldFx, null));
                o.add(cycleRow("Particle", FriendUtilClient.PFX_NAMES, () -> FriendUtilClient.hitType, v -> FriendUtilClient.hitType = v));
                break;
            case "ore_esp":
                o.add(cycleRow("Mode", FriendUtilClient.BO_MODE_NAMES, () -> FriendUtilClient.oeMode, v -> FriendUtilClient.oeMode = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.oeLine, v -> FriendUtilClient.oeLine = v));
                o.add(cycleRow("Pulse", FriendUtilClient.OFFON_NAMES, () -> FriendUtilClient.oePulse, v -> FriendUtilClient.oePulse = v));
                o.add(cycleRow("Tracers", FriendUtilClient.OFFON_NAMES, () -> FriendUtilClient.oeTracers, v -> FriendUtilClient.oeTracers = v));
                o.add(cycleRow("Range", FriendUtilClient.ORE_RANGE_NAMES, () -> FriendUtilClient.oeRange, v -> FriendUtilClient.oeRange = v));
                break;
            case "targetesp":
                o.addAll(colorRows("te", () -> FriendUtilClient.teColor, v -> FriendUtilClient.teColor = v));
                o.add(cycleRow("Style", FriendUtilClient.TE_STYLE_NAMES, () -> FriendUtilClient.teStyle, v -> FriendUtilClient.teStyle = v));
                o.add(cycleRow("Size", FriendUtilClient.SIZE_NAMES, () -> FriendUtilClient.teSize, v -> FriendUtilClient.teSize = v));
                o.add(cycleRow("Speed", FriendUtilClient.SPEED_NAMES, () -> FriendUtilClient.teSpeed, v -> FriendUtilClient.teSpeed = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.teLine, v -> FriendUtilClient.teLine = v));
                break;
            case "trails":
                o.addAll(colorRows("tr", () -> FriendUtilClient.trColor, v -> FriendUtilClient.trColor = v));
                o.add(cycleRow("Length", FriendUtilClient.TR_LEN_NAMES, () -> FriendUtilClient.trLength, v -> FriendUtilClient.trLength = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.trLine, v -> FriendUtilClient.trLine = v));
                o.add(cycleRow("Who", FriendUtilClient.TR_WHO_NAMES, () -> FriendUtilClient.trWho, v -> FriendUtilClient.trWho = v));
                break;
            case "jumpcircles":
                o.addAll(colorRows("jc", () -> FriendUtilClient.jcColor, v -> FriendUtilClient.jcColor = v));
                o.add(cycleRow("Radius", FriendUtilClient.SIZE_NAMES, () -> FriendUtilClient.jcRadius, v -> FriendUtilClient.jcRadius = v));
                o.add(cycleRow("Speed", FriendUtilClient.SPEED_NAMES, () -> FriendUtilClient.jcSpeed, v -> FriendUtilClient.jcSpeed = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.jcLine, v -> FriendUtilClient.jcLine = v));
                break;
            case "blockoverlay":
                o.addAll(colorRows("bo", () -> FriendUtilClient.boColor, v -> FriendUtilClient.boColor = v));
                o.add(cycleRow("Mode", FriendUtilClient.BO_MODE_NAMES, () -> FriendUtilClient.boMode, v -> FriendUtilClient.boMode = v));
                o.add(cycleRow("Line", FriendUtilClient.LINE_NAMES, () -> FriendUtilClient.boLine, v -> FriendUtilClient.boLine = v));
                o.add(cycleRow("Pulse", FriendUtilClient.OFFON_NAMES, () -> FriendUtilClient.boPulse, v -> FriendUtilClient.boPulse = v));
                break;
            case "fog":
                o.addAll(colorRows("fog", () -> FriendUtilClient.fogColorIdx, v -> FriendUtilClient.fogColorIdx = v));
                o.add(cycleRow("Distance", FriendUtilClient.FOG_DIST_NAMES, () -> FriendUtilClient.fogDistIdx, v -> FriendUtilClient.fogDistIdx = v));
                o.add(cycleRow("Start", FriendUtilClient.FOG_START_NAMES, () -> FriendUtilClient.fogStartIdx, v -> FriendUtilClient.fogStartIdx = v));
                o.add(cycleRow("Sky", FriendUtilClient.SKY_NAMES, () -> FriendUtilClient.skyMode, v -> FriendUtilClient.skyMode = v));
                break;
            case "worldpart":
                o.add(cycleRow("Type", FriendUtilClient.PFX_NAMES, () -> FriendUtilClient.wpType, v -> FriendUtilClient.wpType = v));
                o.add(cycleRow("Density", FriendUtilClient.DENSITY_NAMES, () -> FriendUtilClient.wpDensity, v -> FriendUtilClient.wpDensity = v));
                o.add(cycleRow("Range", FriendUtilClient.RANGE_NAMES, () -> FriendUtilClient.wpRange, v -> FriendUtilClient.wpRange = v));
                break;
            default:
                break;
        }
        return o;
    }

    private static List<Row> worldRows(int accent) {
        List<Row> out = new ArrayList<>();
        int wn = FriendUtilClient.WEATHER_NAMES.length, tn = FriendUtilClient.TINT_NAMES.length;
        out.add(new Row("Weather: " + FriendUtilClient.WEATHER_NAMES[FriendUtilClient.weatherMode], accent,
                FriendUtilClient.weatherMode != 0,
                () -> FriendUtilClient.weatherMode = (FriendUtilClient.weatherMode + 1) % wn,
                () -> FriendUtilClient.weatherMode = (FriendUtilClient.weatherMode + wn - 1) % wn));
        out.add(new Row("Tint: " + FriendUtilClient.TINT_NAMES[FriendUtilClient.tintMode], accent,
                FriendUtilClient.tintMode != 0,
                () -> FriendUtilClient.tintMode = (FriendUtilClient.tintMode + 1) % tn,
                () -> FriendUtilClient.tintMode = (FriendUtilClient.tintMode + tn - 1) % tn));
        if (FriendUtilClient.tintMode != 0) {
            out.add(new Row("  Strength " + FriendUtilClient.TINT_STRENGTH[FriendUtilClient.tintStrength] + "%", 0xFFFFFF55, false,
                    () -> FriendUtilClient.tintStrength = (FriendUtilClient.tintStrength + 1) % FriendUtilClient.TINT_STRENGTH.length,
                    null));
        }
        out.add(cycleRow("Distance", FriendUtilClient.RD_NAMES, () -> FriendUtilClient.rdIndex, v -> FriendUtilClient.rdIndex = v));
        Module pm = find("particles");
        if (pm != null) {
            out.add(new Row(pm.name, accent, pm.enabled, () -> pm.enabled = !pm.enabled, null));
        }
        out.add(new Row("  Type: " + FriendUtilClient.PFX_NAMES[FriendUtilClient.particleType], 0xFFFFFF55, false,
                () -> FriendUtilClient.particleType = (FriendUtilClient.particleType + 1) % FriendUtilClient.PFX_NAMES.length,
                null));
        out.add(new Row("  Mode: " + FriendUtilClient.PMODE_NAMES[FriendUtilClient.particleMode], 0xFFFFFF55, false,
                () -> FriendUtilClient.particleMode = (FriendUtilClient.particleMode + 1) % FriendUtilClient.PMODE_NAMES.length,
                null));
        out.add(new Row("  Hit fx: " + (FriendUtilClient.hitWorldFx ? "On" : "Off"), 0xFFFFFF55, false,
                () -> FriendUtilClient.hitWorldFx = !FriendUtilClient.hitWorldFx,
                null));
        return out;
    }

    private static List<Row> rows(int p, long now) {
        List<Row> out = new ArrayList<>();
        if (!OPEN[p]) return out;
        int accent = FriendUtilClient.hudColor(now, p * 220);
        if (p == ORES_PANEL) {
            for (String[] o : ORES) {
                String key = o[1];
                out.add(new Row(o[0], accent, FriendUtilClient.mineSet.contains(key), () -> {
                    if (!FriendUtilClient.mineSet.remove(key)) FriendUtilClient.mineSet.add(key);
                }, null));
            }
            return out;
        }
        if (p == WORLD_PANEL) {
            out.addAll(worldRows(accent));
            return out;
        }
        String[] cat = CATEGORIES[p];
        for (int i = 1; i < cat.length; i++) {
            Module m = find(cat[i]);
            if (m == null) continue;
            boolean has = hasSettings(m.id);
            out.add(new Row(m.name, accent, m.enabled, () -> m.enabled = !m.enabled,
                    has ? () -> { if (!EXPANDED.remove(m.id)) EXPANDED.add(m.id); } : null));
            if (has && EXPANDED.contains(m.id)) out.addAll(settingsRows(m.id));
        }
        return out;
    }

    @Override
    protected void init() {
        w = Mth.clamp((this.width - 6 - (PANELS - 1) * GAP) / PANELS, 58, 78);
        if (!placed) {
            int perRow = Math.max(1, (this.width - 6 + GAP) / (w + GAP));
            for (int i = 0; i < PANELS; i++) {
                PX[i] = 3 + (i % perRow) * (w + GAP);
                PY[i] = 4 + (i / perRow) * 100;
            }
            placed = true;
        }
        for (int i = 0; i < PANELS; i++) {
            PX[i] = Mth.clamp(PX[i], 0, Math.max(0, this.width - w));
            PY[i] = Mth.clamp(PY[i], 0, Math.max(0, this.height - HH));
        }

        // custom block id (AutoMine / Ore ESP), shown only while the Ores panel is open
        box = new EditBox(this.font, (this.width - 130) / 2, this.height - 34, 130, 14, Component.literal("block id"));
        box.setMaxLength(64);
        box.setValue(FriendUtilClient.customQuery);
        box.setResponder(s -> FriendUtilClient.customQuery = s.trim().toLowerCase());
        box.visible = OPEN[ORES_PANEL];
        this.addRenderableWidget(box);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        super.extractRenderState(g, mx, my, a);
        long now = System.currentTimeMillis();
        box.visible = OPEN[ORES_PANEL];

        for (int p = 0; p < PANELS; p++) {
            int x = PX[p], y = PY[p];
            List<Row> rows = rows(p, now);
            int h = HH + 1;
            for (Row r0 : rows) h += rowH(r0);

            g.fill(x, y, x + w, y + h, 0xD0121216);
            g.fill(x, y, x + w, y + HH, 0xF01A1A22);
            for (int i = 0; i < w; i += 2) {
                g.fill(x + i, y + HH - 1, x + Math.min(w, i + 2), y + HH, FriendUtilClient.hudColor(now, i * 14 + p * 220));
            }
            g.text(this.font, title(p), x + 4, y + 3, 0xFFFFFFFF, true);
            g.text(this.font, OPEN[p] ? "-" : "+", x + w - 8, y + 3, 0xFFAAAAAA, true);

            int ry = y + HH;
            for (Row r : rows) {
                int rh = rowH(r);
                if (r.pick() != null) {
                    int cols = palCols(), n = FriendUtilClient.COLOR_NAMES.length, sel = r.swatch().getAsInt();
                    for (int i = 0; i < n; i++) {
                        int sx = x + 4 + (i % cols) * SW, sy = ry + 1 + (i / cols) * SW;
                        g.fill(sx, sy, sx + SW - 1, sy + SW - 1, 0xFF000000 | FriendUtilClient.fxRgb(i, now, i * 8));
                        if (i == sel) {
                            g.fill(sx - 1, sy - 1, sx + SW, sy, 0xFFFFFFFF);
                            g.fill(sx - 1, sy + SW - 1, sx + SW, sy + SW, 0xFFFFFFFF);
                            g.fill(sx - 1, sy, sx, sy + SW - 1, 0xFFFFFFFF);
                            g.fill(sx + SW - 1, sy, sx + SW, sy + SW - 1, 0xFFFFFFFF);
                        }
                    }
                    ry += rh;
                    continue;
                }
                boolean hover = mx >= x && mx < x + w && my >= ry && my < ry + RH;
                if (r.on()) {
                    g.fill(x, ry, x + w, ry + RH, (r.color() & 0x00FFFFFF) | 0x30000000);
                    g.fill(x, ry, x + 1, ry + RH, r.color());
                }
                if (hover) g.fill(x, ry, x + w, ry + RH, 0x20FFFFFF);
                g.text(this.font, r.text(), x + 5, ry + 1, r.on() ? r.color() : (r.click() != null && r.color() == 0xFFFFFF55 ? 0xFFFFFF55 : 0xFFAAAAAA), true);
                if (r.swatch() != null) {
                    g.fill(x + w - 18, ry + 2, x + w - 10, ry + RH - 2, 0xFF000000 | FriendUtilClient.fxRgb(r.swatch().getAsInt(), now, 0));
                }
                if (r.rclick() != null) g.text(this.font, ">", x + w - 7, ry + 1, 0xFF666666, true);
                ry += rh;
            }
        }

        if (OPEN[ORES_PANEL]) {
            String lbl = "Custom block id";
            g.text(this.font, lbl, (this.width - this.font.width(lbl)) / 2, this.height - 45, 0xFF888888, true);
        }
        String hint = "LMB toggle  |  RMB settings  |  drag headers";
        g.text(this.font, hint, (this.width - this.font.width(hint)) / 2, this.height - 12, 0xFF777777, true);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int btn = event.button();
        long now = System.currentTimeMillis();
        for (int p = 0; p < PANELS; p++) {
            int x = PX[p], y = PY[p];
            if (mx < x || mx >= x + w || my < y) continue;
            if (my < y + HH) {
                if (btn == 0) {
                    dragPanel = p;
                    dragDX = (int) mx - x;
                    dragDY = (int) my - y;
                    dragMoved = false;
                } else if (btn == 1) {
                    OPEN[p] = !OPEN[p];
                }
                return true;
            }
            List<Row> rows = rows(p, now);
            int ry = y + HH;
            for (Row r : rows) {
                int rh = rowH(r);
                if (my >= ry && my < ry + rh) {
                    if (r.pick() != null) {
                        int cols = palCols();
                        int col = ((int) mx - x - 4) / SW, row = ((int) my - ry - 1) / SW;
                        int idx = row * cols + col;
                        if (btn == 0 && col >= 0 && col < cols && row >= 0 && idx < FriendUtilClient.COLOR_NAMES.length) {
                            r.pick().accept(idx);
                        }
                    } else if (btn == 0 && r.click() != null) {
                        r.click().run();
                    } else if (btn == 1 && r.rclick() != null) {
                        r.rclick().run();
                    }
                    return true;
                }
                ry += rh;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragPanel >= 0) {
            PX[dragPanel] = Mth.clamp((int) event.x() - dragDX, 0, Math.max(0, this.width - w));
            PY[dragPanel] = Mth.clamp((int) event.y() - dragDY, 0, Math.max(0, this.height - HH));
            dragMoved = true;
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (dragPanel >= 0) {
            if (!dragMoved) OPEN[dragPanel] = !OPEN[dragPanel];   // a plain click on the header folds the panel
            dragPanel = -1;
            return true;
        }
        return super.mouseReleased(event);
    }
}
