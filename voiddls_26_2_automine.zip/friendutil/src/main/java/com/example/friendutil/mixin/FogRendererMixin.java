package com.example.friendutil.mixin;

import com.example.friendutil.FriendUtilClient;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {

    // 26.1+: setupFog returns the FogData that is later uploaded to the shaders.
    @ModifyReturnValue(method = "setupFog", at = @At("RETURN"), require = 0)
    private FogData friendutil$fog(FogData original) {
        FriendUtilClient.applyFog(original);
        return original;
    }
}
